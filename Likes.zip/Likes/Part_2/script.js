var count = 0;
var count2 = 0;
var count3 = 0;

var countElement = document.getElementById("top");
var countElement2 = document.getElementById("mid");
var countElement3 = document.getElementById("bot");

function addLikes(){
    count++;
    countElement.innerText = count + " like(s)";
}
function addLikes2(){
    count2++;
    countElement2.innerText = count2 + " like(s)"
}
function addLikes3(){
    count3++;
    countElement3.innerText = count3 + " like(s)"
}
