var count = 0;
var countElement = document.querySelector("h2");

function addLikes(){
    count++;
    countElement.innerText = count + " like(s)";
}