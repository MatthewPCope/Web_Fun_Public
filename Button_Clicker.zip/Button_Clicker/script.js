function changeToLogout(e){
    if(e.innerText == "Login"){
        e.innerText = "Logout"
    } 
    else{
        e.innerText = "Login"
    }
}
function deleteButton(id){
    document.getElementById(id).remove()
}

